// Java Combat Animation - behavior pack (author: Chriel)
//
// Every tick: look at the item the player is holding, work out its Java attack
// cooldown, and while the weapon is still recharging show a small bar under
// the crosshair (via the on-screen subtitle). The cooldown restarts when you
// hit something and when you change the held item, like Java Edition.
import { world, system } from "@minecraft/server";
import { attackSpeedFor, strengthAt, litSegments, barText } from "./cooldownLogic.js";

// Per-player state: { last: tick of last swing/equip, item: id@slot, shown: lit segments or -1 }
const states = new Map();

function stateFor(player) {
  let s = states.get(player.id);
  if (!s) {
    // Start fully charged (a very old swing time).
    s = { last: -100000, item: "", shown: -1 };
    states.set(player.id, s);
  }
  return s;
}

// A player hit an entity -> Java restarts the cooldown.
world.afterEvents.entityHitEntity.subscribe((event) => {
  const attacker = event.damagingEntity;
  if (attacker && attacker.typeId === "minecraft:player") {
    stateFor(attacker).last = system.currentTick;
  }
});

world.afterEvents.playerLeave.subscribe((event) => {
  states.delete(event.playerId);
});

function heldItem(player) {
  const container = player.getComponent("inventory")?.container;
  return container ? container.getItem(player.selectedSlotIndex) : undefined;
}

function clearBar(player, state) {
  if (state.shown !== -1) {
    state.shown = -1;
    try {
      player.runCommand("title @s clear");
    } catch (e) {}
  }
}

system.runInterval(() => {
  const tick = system.currentTick;
  for (const player of world.getAllPlayers()) {
    try {
      const state = stateFor(player);
      const item = heldItem(player);
      const typeId = item ? item.typeId : "";

      // Changing the held item restarts the cooldown (Java behaviour).
      const key = typeId + "@" + player.selectedSlotIndex;
      if (key !== state.item) {
        if (state.item !== "") state.last = tick;
        state.item = key;
      }

      const speed = attackSpeedFor(typeId);
      const strength = strengthAt(tick - state.last, speed);

      if (strength >= 1) {
        clearBar(player, state);
        continue;
      }
      const lit = litSegments(strength);
      if (lit !== state.shown || tick % 3 === 0) {
        state.shown = lit;
        player.onScreenDisplay.setTitle(" ", {
          subtitle: barText(strength),
          fadeInDuration: 0,
          stayDuration: 4,
          fadeOutDuration: 0,
        });
      }
    } catch (e) {
      // Never let one player/tick error stop the loop.
    }
  }
}, 1);
