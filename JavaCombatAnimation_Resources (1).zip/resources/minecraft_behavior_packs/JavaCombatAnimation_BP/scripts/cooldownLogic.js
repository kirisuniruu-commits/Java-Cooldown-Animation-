// cooldownLogic.js - pure logic (no Minecraft imports) so it can be unit tested.
// Port of Java Edition 1.9+ attack cooldown:
//   period (ticks) = 20 / attackSpeed
//   strength       = clamp(ticksSinceSwing / period, 0, 1)

// Java attack speeds by item id. Anything not listed counts as a fist (4.0).
const FIXED_SPEED = {
  "minecraft:mace": 0.6,
  "minecraft:trident": 1.1,
};

// [wooden, stone, copper, iron, golden, diamond, netherite]
const TIERS = ["wooden", "stone", "copper", "iron", "golden", "diamond", "netherite"];
const TIER_SPEED = {
  axe:   [0.8, 0.8, 0.8, 0.9, 1.0, 1.0, 1.0],
  hoe:   [1.0, 2.0, 2.0, 3.0, 1.0, 4.0, 4.0],
  spear: [1.54, 1.33, 1.18, 1.05, 1.05, 0.95, 0.87],
};
const FLAT_SPEED = { sword: 1.6, pickaxe: 1.2, shovel: 1.0 };

export const FIST_SPEED = 4.0;

export function attackSpeedFor(typeId) {
  if (!typeId) return FIST_SPEED;
  if (FIXED_SPEED[typeId] !== undefined) return FIXED_SPEED[typeId];
  const m = /^minecraft:([a-z]+)_([a-z]+)$/.exec(typeId);
  if (!m) return FIST_SPEED;
  const [, tier, kind] = m;
  if (FLAT_SPEED[kind] !== undefined && TIERS.includes(tier)) return FLAT_SPEED[kind];
  if (TIER_SPEED[kind] && TIERS.includes(tier)) return TIER_SPEED[kind][TIERS.indexOf(tier)];
  return FIST_SPEED;
}

export function cooldownTicks(speed) {
  return 20 / speed;
}

export function strengthAt(ticksSinceSwing, speed) {
  return Math.min(1, Math.max(0, ticksSinceSwing / cooldownTicks(speed)));
}

export const SEGMENTS = 10;

// Number of lit segments, like Java's (int)(strength * N) fill.
export function litSegments(strength) {
  return Math.min(SEGMENTS, Math.max(0, Math.floor(strength * SEGMENTS)));
}

// Text bar: white blocks = charged, dark gray blocks = still recharging.
export function barText(strength) {
  const lit = litSegments(strength);
  return "\u00a7f" + "\u2588".repeat(lit) + "\u00a78" + "\u2588".repeat(SEGMENTS - lit);
}
